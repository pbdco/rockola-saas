import { useFormik } from 'formik';
import { useTranslation } from 'next-i18next';
import { useRouter } from 'next/router';
import { Button, Input, Select, Checkbox } from 'react-daisyui';
import toast from 'react-hot-toast';
import { defaultHeaders } from 'lib/common';
import type { ApiResponse } from 'types';
import type { SerializedVenue } from 'models/venue';
import useVenues from 'hooks/useVenues';

interface EditVenueFormProps {
  venue: SerializedVenue;
  onSuccess?: () => void;
  onCancel?: () => void;
}

const EditVenueForm = ({ venue, onSuccess, onCancel }: EditVenueFormProps) => {
  const { t } = useTranslation('common');
  const router = useRouter();
  const { slug } = router.query as { slug: string };
  const { mutate } = useVenues();

  const formik = useFormik({
    initialValues: {
      name: venue.name,
      slug: venue.slug,
      address: venue.address || '',
      mode: venue.mode,
      spotifyClientId: venue.spotifyClientId || '',
      spotifyClientSecret: venue.spotifyClientSecret || '',
      pricingEnabled: venue.pricingEnabled,
      pricePerSong: venue.pricePerSong?.toString() || '',
      currency: venue.currency || 'USD',
      isActive: venue.isActive,
    },
    onSubmit: async (values) => {
      try {
        const payload = {
          name: values.name,
          slug: values.slug || undefined,
          address: values.address || undefined,
          mode: values.mode,
          spotifyClientId: values.spotifyClientId || undefined,
          spotifyClientSecret: values.spotifyClientSecret || undefined,
          pricingEnabled: values.pricingEnabled,
          pricePerSong:
            values.pricingEnabled && values.pricePerSong
              ? parseFloat(values.pricePerSong)
              : null,
          currency: values.currency,
          isActive: values.isActive,
        };

        const response = await fetch(
          `/api/teams/${slug}/venues/${venue.id}`,
          {
            method: 'PUT',
            headers: defaultHeaders,
            body: JSON.stringify(payload),
          }
        );

        const json = (await response.json()) as ApiResponse<SerializedVenue>;

        if (!response.ok) {
          throw new Error(json.error.message);
        }

        toast.success(t('venue-updated'));
        mutate();
        onSuccess?.();
      } catch (error: any) {
        toast.error(error.message);
      }
    },
  });

  return (
    <form onSubmit={formik.handleSubmit} className="space-y-8">
      {/* Basic Information Section */}
      <div className="space-y-4">
        <h2 className="text-xl font-semibold">{t('basic-information')}</h2>
        
        <div className="form-control">
          <label className="label">
            <span className="label-text font-medium">{t('venue-name')}</span>
          </label>
          <Input
            name="name"
            type="text"
            placeholder={t('venue-name-placeholder')}
            value={formik.values.name}
            onChange={formik.handleChange}
            required
          />
        </div>

        <div className="form-control">
          <label className="label">
            <span className="label-text font-medium">{t('venue-slug')}</span>
          </label>
          <Input
            name="slug"
            type="text"
            placeholder={t('venue-slug-placeholder')}
            value={formik.values.slug}
            onChange={formik.handleChange}
            required
          />
          <label className="label">
            <span className="label-text-alt">{t('venue-slug-help')}</span>
          </label>
        </div>

        <div className="form-control">
          <label className="label">
            <span className="label-text font-medium">{t('address')}</span>
            <span className="label-text-alt">{t('optional')}</span>
          </label>
          <Input
            name="address"
            type="text"
            placeholder={t('venue-address-placeholder')}
            value={formik.values.address}
            onChange={formik.handleChange}
          />
        </div>

        <div className="form-control">
          <label className="label">
            <span className="label-text font-medium">{t('venue-mode')}</span>
          </label>
          <Select
            name="mode"
            value={formik.values.mode}
            onChange={formik.handleChange}
          >
            <option value="QUEUE">{t('mode-queue')}</option>
            <option value="PLAYLIST">{t('mode-playlist')}</option>
            <option value="AUTOMATION">{t('mode-automation')}</option>
          </Select>
          <label className="label">
            <span className="label-text-alt">{t('venue-mode-help')}</span>
          </label>
        </div>
      </div>

      <div className="divider"></div>

      {/* Spotify Configuration Section */}
      <div className="space-y-4">
        <div>
          <h2 className="text-xl font-semibold">{t('spotify-configuration')}</h2>
          <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
            {t('spotify-configuration-description')}
          </p>
        </div>
        
        <div className="alert alert-info">
          <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" className="stroke-current shrink-0 w-6 h-6">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path>
          </svg>
          <span className="text-sm">{t('spotify-credentials-help')}</span>
        </div>

        <div className="form-control">
          <label className="label">
            <span className="label-text font-medium">{t('spotify-client-id')}</span>
            <span className="label-text-alt">{t('required-for-spotify')}</span>
          </label>
          <Input
            name="spotifyClientId"
            type="text"
            placeholder={t('spotify-client-id-placeholder')}
            value={formik.values.spotifyClientId}
            onChange={formik.handleChange}
          />
          <label className="label">
            <span className="label-text-alt">{t('spotify-client-id-help')}</span>
          </label>
        </div>

        <div className="form-control">
          <label className="label">
            <span className="label-text font-medium">{t('spotify-client-secret')}</span>
            <span className="label-text-alt">{t('required-for-spotify')}</span>
          </label>
          <Input
            name="spotifyClientSecret"
            type="password"
            placeholder={t('spotify-client-secret-placeholder')}
            value={formik.values.spotifyClientSecret}
            onChange={formik.handleChange}
          />
          <label className="label">
            <span className="label-text-alt">{t('spotify-client-secret-help')}</span>
          </label>
        </div>
      </div>

      <div className="divider"></div>

      {/* Pricing Section */}
      <div className="space-y-4">
        <div>
          <h2 className="text-xl font-semibold">{t('pricing-settings')}</h2>
          <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
            {t('pricing-settings-description')}
          </p>
        </div>

        <div className="form-control">
          <label className="label cursor-pointer justify-start gap-2">
            <Checkbox
              name="pricingEnabled"
              checked={formik.values.pricingEnabled}
              onChange={formik.handleChange}
            />
            <span className="label-text font-medium">{t('enable-pricing')}</span>
          </label>
        </div>

        {formik.values.pricingEnabled && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pl-8">
            <div className="form-control">
              <label className="label">
                <span className="label-text font-medium">{t('price-per-song')}</span>
              </label>
              <Input
                name="pricePerSong"
                type="number"
                step="0.01"
                min="0"
                max="1000"
                placeholder="2.99"
                value={formik.values.pricePerSong}
                onChange={formik.handleChange}
              />
            </div>

            <div className="form-control">
              <label className="label">
                <span className="label-text font-medium">{t('currency')}</span>
              </label>
              <Select
                name="currency"
                value={formik.values.currency}
                onChange={formik.handleChange}
              >
                <option value="USD">USD</option>
                <option value="EUR">EUR</option>
                <option value="GBP">GBP</option>
                <option value="MXN">MXN</option>
                <option value="ARS">ARS</option>
              </Select>
            </div>
          </div>
        )}
      </div>

      <div className="divider"></div>

      {/* Status Section */}
      <div className="space-y-4">
        <div>
          <h2 className="text-xl font-semibold">{t('venue-status')}</h2>
          <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
            {t('venue-status-description')}
          </p>
        </div>

        <div className="form-control">
          <label className="label cursor-pointer justify-start gap-2">
            <Checkbox
              name="isActive"
              checked={formik.values.isActive}
              onChange={formik.handleChange}
            />
            <span className="label-text font-medium">{t('venue-is-active')}</span>
          </label>
          <label className="label">
            <span className="label-text-alt">{t('venue-is-active-help')}</span>
          </label>
        </div>
      </div>

      {/* Action Buttons */}
      <div className="flex gap-3 pt-4">
        <Button
          type="submit"
          color="primary"
          loading={formik.isSubmitting}
          disabled={formik.isSubmitting}
          size="lg"
        >
          {t('save-changes')}
        </Button>
        {onCancel && (
          <Button
            type="button"
            variant="outline"
            onClick={onCancel}
            disabled={formik.isSubmitting}
            size="lg"
          >
            {t('cancel')}
          </Button>
        )}
      </div>
    </form>
  );
};

export default EditVenueForm;

