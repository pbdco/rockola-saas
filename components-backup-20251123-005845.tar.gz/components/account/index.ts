export { default as UpdatePassword } from './UpdatePassword';
export { default as UpdateAccount } from './UpdateAccount';
